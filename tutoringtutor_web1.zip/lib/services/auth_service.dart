import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/kid.dart';

class AuthService {
  //for storing data in cloud firestore
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  //for authentication
  final FirebaseAuth _auth = FirebaseAuth.instance;

  //for signUp
  Future<String> signUpUser({
    required String email,
    required String password,
    required String parentTitle,
    required String firstName,
    required String middleName,
    required String lastName,
    required String addressLine1,
    required String addressLine2,
    required String addressLine3,
    required String city,
    required String postalCode,
    required String phoneNo,
    required String secretQuestion,
    required String secretAnswer,
  }) async {
    String res = " Error Occured";
    try {
      if (email.isNotEmpty ||
          password.isNotEmpty ||
          parentTitle.isNotEmpty ||
          firstName.isNotEmpty ||
          middleName.isNotEmpty ||
          lastName.isNotEmpty ||
          addressLine1.isNotEmpty ||
          addressLine2.isNotEmpty ||
          addressLine3.isNotEmpty ||
          city.isNotEmpty ||
          postalCode.isNotEmpty ||
          phoneNo.isNotEmpty ||
          secretQuestion.isNotEmpty ||
          secretAnswer.isNotEmpty) {
        // for registering user in firebase auth with email and password
        UserCredential credential = await _auth.createUserWithEmailAndPassword(
            email: email, password: password);
        //for adding user to our cloud firestore
        await _firestore.collection("users").doc(credential.user!.uid).set({
          'email': email,
          'uid': credential.user!.uid,
          "parentTitle": parentTitle,
          "firstName": firstName,
          "middleName": middleName,
          "lastName": lastName,
          "addressLine1": addressLine1,
          "addressLine2": addressLine2,
          "addressLine3": addressLine3,
          "city": city,
          "postalCode": postalCode,
          "phoneNo": phoneNo,
          "secretQuestion": secretQuestion,
          "secretAnswer": secretAnswer,
        });
        res = "success";
      }
    } catch (e) {
      res = e.toString().split(']')[1];
    }
    return res;
  }

  // login screen authentication
  Future<String> loginUser({
    required String email,
    required String password,
  }) async {
    String res = " Error Occured";
    try {
      if (email.isNotEmpty || password.isNotEmpty) {
        await _auth.signInWithEmailAndPassword(
          email: email,
          password: password,
        );
        res = "success";
      } else {
        res = "Please enter all the fields";
      }
    } catch (e) {
      res = e.toString().split(']')[1];
      print(e.toString());
    }
    return res;
  }

  //Log out
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // Register kids
  Future<void> registerKids(List<Kid> kids) async {
    final firestore = FirebaseFirestore.instance;
    // use batches to avoid multiple queries to firebase
    final batch = firestore.batch();

    for (Kid kid in kids) {
      final docRef = firestore.collection('kids').doc();
      // Add the set operation to the batch
      batch.set(docRef, kid.toMap());
    }

    try {
      // Commit all operations in the batch
      await batch.commit();
      print('All kids registered successfully!');
    } catch (e) {
      print('Error adding kids: $e');
    }
  }
}
