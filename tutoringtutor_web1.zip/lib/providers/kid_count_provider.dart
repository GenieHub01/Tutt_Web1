import 'package:flutter/material.dart';

class KidCountProvider with ChangeNotifier {
  int _kidCount = 0;

  int get kidCount => _kidCount;

  void increaseKid() {
    _kidCount++;
    notifyListeners();
  }

  void decreaseKid() {
    if (_kidCount > 0) {
      _kidCount--;
      notifyListeners();
    }
  }
}
