import 'package:flutter/foundation.dart';

import '../models/kid.dart';

class ChildrenProvider with ChangeNotifier {
  List<Kid> _kids = [];

  List<Kid> get kids => _kids;

  void addKid(Kid kid) {
    _kids.add(kid);
    notifyListeners();
  }

  void removeKid(int index) {
    if (index >= 0 && index < _kids.length) {
      _kids.removeAt(index);
      notifyListeners();
    }
  }

  void updateKid(int index, Kid newKid) {
    if (index >= 0 && index < _kids.length) {
      _kids[index] = newKid;
      notifyListeners();
    }
  }
}
