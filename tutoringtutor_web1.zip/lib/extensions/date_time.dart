extension DateTimeExtension on DateTime {
  String printDate() =>
      toString().toString().substring(0, 11).replaceAll("-", "/");
}
