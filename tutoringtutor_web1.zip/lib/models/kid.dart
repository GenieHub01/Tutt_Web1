// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class Kid {
  String alliasName;
  String parentName;
  String parentMiddleName;
  String parentLastName;
  DateTime? DOB;
  String? gender;
  String? subscriptionType;
  int? age;

  Kid({
    required this.alliasName,
    required this.parentName,
    required this.parentMiddleName,
    required this.parentLastName,
    this.DOB,
    this.gender,
    this.subscriptionType,
    this.age,
  });

  Kid copyWith(
      {String? alliasName,
      String? parentName,
      String? parentMiddleName,
      String? parentLastName,
      DateTime? DOB,
      String? gender,
      String? subscriptionType,
      int? age}) {
    return Kid(
        alliasName: alliasName ?? this.alliasName,
        parentName: parentName ?? this.parentName,
        parentMiddleName: parentMiddleName ?? this.parentMiddleName,
        parentLastName: parentLastName ?? this.parentLastName,
        DOB: DOB ?? this.DOB,
        gender: gender ?? this.gender,
        subscriptionType: subscriptionType ?? this.subscriptionType,
        age: age ?? this.age);
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'alliasName': alliasName,
      'parentName': parentName,
      'parentMiddleName': parentMiddleName,
      'parentLastName': parentLastName,
      'DOB': DOB,
      'gender': gender,
      'subscriptionType': subscriptionType,
      'age': age
    };
  }

  factory Kid.fromMap(Map<String, dynamic> map) {
    return Kid(
      alliasName: map['alliasName'] as String,
      parentName: map['parentName'] as String,
      parentMiddleName: map['parentMiddleName'] as String,
      parentLastName: map['parentLastName'] as String,
      DOB: map['DOB'] != null ? map['DOB'] as DateTime : null,
      gender: map['gender'] != null ? map['gender'] as String : null,
      subscriptionType: map['subscriptionType'] != null
          ? map['subscriptionType'] as String
          : null,
      age: map['age'] != null ? map['age'] as int : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory Kid.fromJson(String source) =>
      Kid.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'Kid(alliasName: $alliasName, parentName: $parentName, parentMiddleName: $parentMiddleName, parentLastName: $parentLastName, DOB: $DOB, gender: $gender, subscriptionType: $subscriptionType, age: $age)';
  }

  @override
  bool operator ==(covariant Kid other) {
    if (identical(this, other)) return true;

    return other.alliasName == alliasName &&
        other.parentName == parentName &&
        other.parentMiddleName == parentMiddleName &&
        other.parentLastName == parentLastName &&
        other.DOB == DOB &&
        other.gender == gender &&
        other.age == age &&
        other.subscriptionType == subscriptionType;
  }

  @override
  int get hashCode {
    return alliasName.hashCode ^
        parentName.hashCode ^
        parentMiddleName.hashCode ^
        parentLastName.hashCode ^
        DOB.hashCode ^
        gender.hashCode ^
        age.hashCode ^
        subscriptionType.hashCode;
  }
}
