enum Gender { boy, girl }

enum SubscriptionType { free, paid }
