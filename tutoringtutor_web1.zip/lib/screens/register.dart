import 'package:flutter/material.dart';
import 'package:tutoringtutor_web1/screens/login.dart';
import 'package:tutoringtutor_web1/services/auth_service.dart';
import 'package:tutoringtutor_web1/themes/colors.dart';
import 'package:tutoringtutor_web1/widgets/button.dart';
import 'package:tutoringtutor_web1/widgets/form_field.dart';
import 'package:tutoringtutor_web1/widgets/snackbar.dart';
import '../themes/theme.dart';
import '../widgets/section_title.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _parentTitleController = TextEditingController();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _middleNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _addressLine1Controller = TextEditingController();
  final TextEditingController _addressLine2Controller = TextEditingController();
  final TextEditingController _addressLine3Controller = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _postalCodeController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _secretQuestionPasswordController =
      TextEditingController();
  final TextEditingController _secretAnswerController = TextEditingController();
  bool isLoading = false;

  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _parentTitleController.dispose();
    _firstNameController.dispose();
    _middleNameController.dispose();
    _lastNameController.dispose();
    _addressLine1Controller.dispose();
    _addressLine2Controller.dispose();
    _addressLine3Controller.dispose();
    _cityController.dispose();
    _postalCodeController.dispose();
    _phoneNumberController.dispose();
    _secretQuestionPasswordController.dispose();
    _secretAnswerController.dispose();
  }

  void signUpUser() async {
    if (_passwordController.text != _confirmPasswordController.text) {
      showSnackBar(context, "Passwords do not match");
      return;
    }
    String res = await AuthService().signUpUser(
        email: _emailController.text,
        password: _passwordController.text,
        parentTitle: _parentTitleController.text,
        firstName: _firstNameController.text,
        middleName: _middleNameController.text,
        lastName: _lastNameController.text,
        addressLine1: _addressLine1Controller.text,
        addressLine2: _addressLine2Controller.text,
        addressLine3: _addressLine3Controller.text,
        city: _cityController.text,
        postalCode: _postalCodeController.text,
        phoneNo: _phoneNumberController.text,
        secretQuestion: _secretQuestionPasswordController.text,
        secretAnswer: _secretAnswerController.text);
    if (res == "success") {
      setState(() {
        isLoading = true;
      });
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => LoginScreen()));
    } else {
      setState(() {
        isLoading = false;
      });
      showSnackBar(context, res);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blueCloudBackgroundColor,
      body: Center(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                alignment: Alignment.center,
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width / 1.5,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/images/white_cloud.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 200),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    surfaceTintColor: Colors.white,
                    elevation: 50,
                    child: Container(
                      padding: const EdgeInsets.all(30),
                      width: MediaQuery.of(context).size.width / 3.5,
                      height: MediaQuery.of(context).size.height / 1.1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          const Text(
                            "Sign Up",
                            style: TextStyle(
                                fontSize: 27, fontWeight: FontWeight.bold),
                          ),
                          const Text(
                            "Please check and enter all required fields",
                            style: TextStyle(
                              color: Color.fromRGBO(0, 0, 0, 0.5),
                            ),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          const SectionTitle(title: "Parent Name: *"),
                          _buildNameFields(),
                          _buildMiddleLastNameFields(),
                          const SectionTitle(title: "Address: *"),
                          FormFieldWidget(
                            hintText: "Address Line 1",
                            textEditingController: _addressLine1Controller,
                          ),
                          FormFieldWidget(
                            hintText: "Address Line 2",
                            textEditingController: _addressLine2Controller,
                          ),
                          FormFieldWidget(
                            hintText: "Address Line 3",
                            textEditingController: _addressLine3Controller,
                          ),
                          _buildCityPostalCodeFields(),
                          const SectionTitle(title: "Phone Number: *"),
                          FormFieldWidget(
                            hintText: "Phone Number",
                            textEditingController: _phoneNumberController,
                          ),
                          const SectionTitle(title: "Email: *"),
                          FormFieldWidget(
                            hintText: "Email Address",
                            textEditingController: _emailController,
                          ),
                          const SectionTitle(title: "Password: *"),
                          _buildPasswordFields(),
                          const SectionTitle(title: "Secret Key:"),
                          FormFieldWidget(
                            hintText: "Secret Question?",
                            textEditingController:
                                _secretQuestionPasswordController,
                          ),
                          FormFieldWidget(
                            hintText: "Secret Answer",
                            textEditingController: _secretAnswerController,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Expanded(
                              child: AppButton(
                            title: "Sign Up",
                            onTap: () => signUpUser(),
                          )),
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNameFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
            child: FormFieldWidget(
          hintText: "Parent Title",
          textEditingController: _parentTitleController,
        )),
        SizedBox(width: 20),
        Expanded(
            child: FormFieldWidget(
          hintText: "First Name",
          textEditingController: _firstNameController,
        )),
      ],
    );
  }

  Widget _buildMiddleLastNameFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
            child: FormFieldWidget(
          hintText: "Middle Name",
          textEditingController: _middleNameController,
        )),
        SizedBox(width: 20),
        Expanded(
            child: FormFieldWidget(
          hintText: "Last Name",
          textEditingController: _lastNameController,
        )),
      ],
    );
  }

  Widget _buildCityPostalCodeFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
            child: FormFieldWidget(
          hintText: "City",
          textEditingController: _cityController,
        )),
        SizedBox(width: 20),
        Expanded(
            child: FormFieldWidget(
          hintText: "Postal Code",
          textEditingController: _postalCodeController,
        )),
      ],
    );
  }

  Widget _buildPasswordFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
            child: FormFieldWidget(
          hintText: "Password",
          isObscure: true,
          textEditingController: _passwordController,
        )),
        SizedBox(width: 20),
        Expanded(
            child: FormFieldWidget(
          isObscure: true,
          hintText: "Confirm Password",
          textEditingController: _confirmPasswordController,
        )),
      ],
    );
  }

  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          "Already have an account?",
          style: TextStyle(fontWeight: FontWeight.w400),
        ),
        TextButton(
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => LoginScreen(),
                ));
          },
          child: const Text(
            "Sign In",
            style: TextStyle(color: Colors.black),
          ),
        ),
      ],
    );
  }
}
