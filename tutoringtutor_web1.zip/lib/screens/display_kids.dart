import 'dart:math';
import 'package:tutoringtutor_web1/providers/kid_information_provider.dart';
import 'package:tutoringtutor_web1/themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/kid.dart';
import '../themes/theme.dart';
import '../widgets/button.dart';

class DisplayKids extends StatelessWidget {
  DisplayKids({super.key});

  @override
  Widget build(BuildContext context) {
    List<Kid> kids = context.watch<ChildrenProvider>().kids;
    return Scaffold(
      backgroundColor: AppColors.blueCloudBackgroundColor,
      body: Center(
        child: Align(
          alignment: Alignment.centerRight,
          child: Container(
            alignment: Alignment.center,
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width / 1.5,
            decoration: AppTheme.whiteCloudBackgroundDecoration,
            child: Padding(
              padding: const EdgeInsets.only(left: 200),
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                surfaceTintColor: Colors.white,
                elevation: 50,
                child: Container(
                  padding: const EdgeInsets.all(30),
                  width: MediaQuery.of(context).size.width / 3.5,
                  height: MediaQuery.of(context).size.height / 1.15,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Your Kids",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 20),
                      kids.length == 1
                          ? Center(
                              child: KidProfile(
                              age: kids[0].age,
                              kidName: kids[0].alliasName,
                            ))
                          : kids.length == 2
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    KidProfile(
                                      age: kids[0].age,
                                      kidName: kids[0].alliasName,
                                    ),
                                    SizedBox(
                                      height: 15,
                                    ),
                                    KidProfile(
                                      age: kids[1].age,
                                      kidName: kids[1].alliasName,
                                    )
                                  ],
                                )
                              : Expanded(
                                  child: GridView.builder(
                                    itemCount: kids.length,
                                    shrinkWrap: true,
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3,
                                      mainAxisSpacing: 12,
                                      crossAxisSpacing: 12,
                                    ),
                                    itemBuilder: (context, index) {
                                      return KidProfile(
                                          age: kids[index].age!!,
                                          kidName: kids[index].alliasName);
                                    },
                                  ),
                                ),
                      SizedBox(height: 20),
                      AppButton(title: "Complete"),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class KidProfile extends StatelessWidget {
  const KidProfile({
    super.key,
    this.age,
    required this.kidName,
  });

  final int? age;
  final String kidName;

  @override
  Widget build(BuildContext context) {
    int randomGen = Random().nextInt(2);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.textFieldHintBackgroundColor,
            image: DecorationImage(
              image: AssetImage(
                  randomGen == 0 ? "images/kid1.png" : "images/kid2.png"),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Flexible(
          fit: FlexFit.loose,
          child: Text(
            kidName,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 22,
              color: AppColors.blueCloudBackgroundColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        Text(
          "Age: ${age ?? ""}",
          style: TextStyle(color: AppColors.textFieldHintTextColor),
        ),
      ],
    );
  }
}
