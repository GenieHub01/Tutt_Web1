import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:provider/provider.dart';

import '../providers/kid_count_provider.dart';
import '../themes/colors.dart';
import '../themes/theme.dart';
import '../widgets/button.dart';
import '../widgets/snackbar.dart';
import 'register_kids_form.dart';

class KidCountScreen extends StatelessWidget {
  const KidCountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<KidCountProvider>(
      builder: (context, value, child) {
        return Scaffold(
          backgroundColor: AppColors.blueCloudBackgroundColor,
          body: Center(
            child: Column(children: [
              Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    alignment: Alignment.center,
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width / 1.5,
                    decoration: AppTheme.whiteCloudBackgroundDecoration,
                    child: Padding(
                        padding: const EdgeInsets.only(left: 200),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          surfaceTintColor: Colors.white,
                          elevation: 50,
                          child: Container(
                            padding: const EdgeInsets.all(30),
                            width: MediaQuery.of(context).size.width / 3.5,
                            height: MediaQuery.of(context).size.height / 1.15,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  "Register Children",
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w900),
                                ),
                                const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 12.0),
                                  child: Text(
                                    "How many children would you like to register?",
                                  ),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(12.0),
                                  child: _AddChildrenWidget(),
                                ),
                                AppButton(
                                  title: "Confirm",
                                  onTap: () {
                                    if (context
                                            .read<KidCountProvider>()
                                            .kidCount >
                                        0) {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              RegisterKidsInfo(),
                                        ),
                                      );
                                    } else {
                                      showSnackBar(context,
                                          "Please enter 1 child or more");
                                    }
                                  },
                                )
                              ],
                            ),
                          ),
                        )),
                  )),
            ]),
          ),
        );
      },
    );
  }
}

class _AddChildrenWidget extends StatelessWidget {
  const _AddChildrenWidget();

  @override
  Widget build(BuildContext context) {
    return Consumer<KidCountProvider>(
      builder: (context, value, child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: IconButton(
                  onPressed: () =>
                      context.read<KidCountProvider>().decreaseKid(),
                  icon: FaIcon(FontAwesomeIcons.minus)),
            ),
            Container(
              color: AppColors.textFieldHintBackgroundColor,
              child: Text(
                context.read<KidCountProvider>().kidCount.toString(),
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: IconButton(
                  onPressed: () =>
                      context.read<KidCountProvider>().increaseKid(),
                  icon: FaIcon(FontAwesomeIcons.plus)),
            ),
          ],
        );
      },
    );
  }
}
