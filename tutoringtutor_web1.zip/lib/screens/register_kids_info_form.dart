import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tutoringtutor_web1/extensions/date_time.dart';

import '../models/enums.dart';
import '../providers/kid_count_provider.dart';
import '../themes/colors.dart';
import '../themes/theme.dart';
import '../widgets/button.dart';
import '../widgets/form_field.dart';
import '../widgets/section_title.dart';
import 'register_kids_form.dart';

class RegisterKidsInfoForm extends StatefulWidget {
  const RegisterKidsInfoForm({super.key});

  @override
  State<RegisterKidsInfoForm> createState() => _RegisterKidsInfoFormState();
}

class _RegisterKidsInfoFormState extends State<RegisterKidsInfoForm> {
  Gender? _gender = Gender.boy;
  SubscriptionType? _subscriptionType = SubscriptionType.free;
  DateTime? _selectedDate = DateTime.now();
  String _childAge = "";

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final kidCount = context.watch<KidCountProvider>().kidCount;
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      surfaceTintColor: Colors.white,
      elevation: 50,
      child: Container(
        padding: const EdgeInsets.all(30),
        width: MediaQuery.of(context).size.width / 3.5,
        height: MediaQuery.of(context).size.height / 1.15,
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              const Text(
                "Register Your Kids Info",
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 15),
              const SectionTitle(title: "Alias Name: *"),
              FormFieldWidget(
                hintText: "RogerRabit008",
                hintTextStyle: const TextStyle(
                    color: Colors.black, fontWeight: FontWeight.w700),
              ),
              const AliasNote(),
              const SectionTitle(title: "Parent Name: *"),
              _buildParentName(),
              _buildDateTimeFields(),
              Align(
                  alignment: Alignment.centerLeft,
                  child: _selectedDate != null
                      ? Text("${calculateAge(_selectedDate!)}")
                      : Text("")),
              const SectionTitle(title: "Gender"),
              _buildGenderRadioButtons(),
              const SectionTitle(title: "Subscription Type"),
              _buildSubscriptionRadioButtons(),
              AppButton(title: "Sign In"),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("1/$kidCount"),
                  IconButton(
                      onPressed: () {
                        Navigator.of(context).push(_createRoute());
                      },
                      icon: Icon(Icons.navigate_next))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildParentName() {
    return Table(
      children: [
        TableRow(children: [
          FormFieldWidget(hintText: "First Name"),
          FormFieldWidget(hintText: "Middle Name"),
        ]),
        TableRow(
            children: [FormFieldWidget(hintText: "Last Name"), Container()]),
      ],
    );
  }

  String calculateAge(DateTime birth) {
    DateTime now = DateTime.now();
    Duration age = now.difference(birth);
    int years = age.inDays ~/ 365;
    int months = (age.inDays % 365) ~/ 30;
    int days = ((age.inDays % 365) % 30);
    setState(() {
      if (!(years == 0 && months == 0 && days == 0)) {
        _childAge = 'Age result: $years years, $months months, and $days days';
      }
    });
    return _childAge;
  }

  Widget _buildDateTimeFields() {
    return Table(
      children: [
        const TableRow(children: [
          SectionTitle(title: "DOB:"),
          // SectionTitle(title: "Time:")
        ]),
        TableRow(children: [
          InkWell(
              onTap: () async {
                _selectedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(1930, 8),
                    lastDate: DateTime.now());
                setState(() {});
              },
              child: Container(
                // height: 50,
                color: AppColors.textFieldHintBackgroundColor,
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _selectedDate != null
                          ? _selectedDate!.printDate()
                          : DateTime.now().printDate(),
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontSize: 17),
                    )),
              )),
        ])
      ],
    );
  }

  Widget _buildGenderRadioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildRadioButton<Gender>(Gender.boy, "Boy", _gender,
            (Gender? newValue) {
          setState(() {
            _gender = newValue;
          });
        }),
        const SizedBox(width: 21),
        _buildRadioButton<Gender>(Gender.girl, "Girl", _gender,
            (Gender? newValue) {
          setState(() {
            _gender = newValue;
          });
        }),
      ],
    );
  }

  Widget _buildSubscriptionRadioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildRadioButton<SubscriptionType>(
            SubscriptionType.free, "Free", _subscriptionType,
            (SubscriptionType? newValue) {
          setState(() {
            _subscriptionType = newValue;
          });
        }),
        const SizedBox(width: 21),
        _buildRadioButton<SubscriptionType>(
            SubscriptionType.paid, "Paid", _subscriptionType,
            (SubscriptionType? newValue) {
          setState(() {
            _subscriptionType = newValue;
          });
        }),
      ],
    );
  }

  Widget _buildRadioButton<T>(
      T value, String text, T? groupValue, ValueChanged<T?> onChanged) {
    return Expanded(
      child: Container(
        color: AppColors.textFieldHintBackgroundColor,
        child: ListTile(
          title: Text(text),
          leading: Radio<T>(
            activeColor: Colors.orange,
            value: value,
            groupValue: groupValue,
            onChanged: onChanged,
          ),
        ),
      ),
    );
  }
}

class AliasNote extends StatelessWidget {
  const AliasNote({super.key});

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: const TextSpan(
        style: TextStyle(color: AppColors.textFieldHintTextColor),
        children: <TextSpan>[
          TextSpan(text: '*', style: TextStyle(color: Colors.red)),
          TextSpan(
              text:
                  ' Note do not use the child\'s real name here, this will be their screen name'),
        ],
      ),
    );
  }
}

Route _createRoute() {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) =>
        RegisterKidsInfoForm(),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = Offset(1.0, 0.0);
      const end = Offset.zero;
      const curve = Curves.ease;

      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

      return SlideTransition(
        position: animation.drive(tween),
        child: child,
      );
    },
  );
}
