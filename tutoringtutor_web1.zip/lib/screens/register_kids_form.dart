import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tutoringtutor_web1/extensions/date_time.dart';

import '../models/enums.dart';
import '../models/kid.dart';
import '../providers/kid_count_provider.dart';
import '../providers/kid_information_provider.dart';
import '../themes/colors.dart';
import '../themes/theme.dart';
import '../widgets/button.dart';
import '../widgets/form_field.dart';
import '../widgets/section_title.dart';
import '../widgets/snackbar.dart';
import 'display_kids.dart';

class RegisterKidsInfo extends StatefulWidget {
  const RegisterKidsInfo({super.key});

  @override
  State<RegisterKidsInfo> createState() => _RegisterKidsInfoState();
}

class _RegisterKidsInfoState extends State<RegisterKidsInfo>
    with SingleTickerProviderStateMixin {
  final TextEditingController _aliasNameController = TextEditingController();
  final TextEditingController _parentFirstNameController =
      TextEditingController();
  final TextEditingController _parentMiddleNameController =
      TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _subscriptionTypeController =
      TextEditingController();
  bool _animationCompleted = false;
  int currentKidCount = 1;

  late AnimationController _controller = AnimationController(
    duration: const Duration(seconds: 3),
    vsync: this,
  )..forward();

  late Animation<Offset> _offsetAnimation = Tween<Offset>(
    begin: Offset.zero,
    end: const Offset(1.5, 0.0),
  ).animate(CurvedAnimation(
    parent: _controller,
    curve: Curves.elasticInOut,
  ));

  @override
  void dispose() {
    _aliasNameController.clear();
    _parentFirstNameController.clear();
    _parentMiddleNameController.clear();
    _lastNameController.clear();
    _dobController.clear();
    _genderController.clear();
    _subscriptionTypeController.clear();
    _controller.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1, milliseconds: 200),
      vsync: this,
    );

    _offsetAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(1.5, 0.0),
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.fastEaseInToSlowEaseOut,
    ));

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _animationCompleted = true;
          // Reset the form after the animation is complete
          _resetForm();
        });
      }
    });
  }

  Gender? _gender = Gender.boy;
  SubscriptionType? _subscriptionType = SubscriptionType.free;
  DateTime? _selectedDate = DateTime.now();
  int _childAge = 0;
  bool _isForm1 = true;

  final _formKey = GlobalKey<FormState>();

  void _resetForm() {
    setState(() {
      _isForm1 = !_isForm1;
      _gender = Gender.boy;
      _subscriptionType = SubscriptionType.free;
      _selectedDate = DateTime.now();
      _childAge = 0;
      _formKey.currentState?.reset();
      // Reset animation completion state
      _animationCompleted = false;
      // Reset the animation controller
      _controller.reset();
      _aliasNameController.clear();
      _parentFirstNameController.clear();
      _parentMiddleNameController.clear();
      _lastNameController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final kidCount = context.watch<KidCountProvider>().kidCount;
    return Scaffold(
      backgroundColor: AppColors.blueCloudBackgroundColor,
      body: Center(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                alignment: Alignment.center,
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width / 1.5,
                decoration: AppTheme.whiteCloudBackgroundDecoration,
                child: Padding(
                  padding: const EdgeInsets.only(left: 0),
                  child: SlideTransition(
                    position: _offsetAnimation,
                    child: _animationCompleted
                        ? _buildForm(context, kidCount)
                        : Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            surfaceTintColor: Colors.white,
                            elevation: 50,
                            child: Container(
                              padding: const EdgeInsets.all(30),
                              width: MediaQuery.of(context).size.width / 3.5,
                              height: MediaQuery.of(context).size.height / 1.15,
                              child: _isForm1
                                  ? _buildForm(context, kidCount)
                                  : _buildForm(context, kidCount),
                            ),
                          ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForm(BuildContext context, int kidCount) {
    return Form(
      key: ValueKey(_isForm1),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          const Text(
            "Register Your Kids Info",
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 15),
          const SectionTitle(title: "Alias Name: *"),
          FormFieldWidget(
            hintText: "RogerRabit008",
            textEditingController: _aliasNameController,
            hintTextStyle: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.w700),
          ),
          const AliasNote(),
          const SectionTitle(title: "Parent Name: *"),
          _buildParentName(),
          _buildDateTimeFields(),
          Align(
            alignment: Alignment.centerLeft,
            child: _selectedDate != null
                ? Text("${_calculateAge(_selectedDate!)}")
                : const Text(""),
          ),
          const SectionTitle(title: "Gender"),
          _buildGenderRadioButtons(),
          const SectionTitle(title: "Subscription Type"),
          _buildSubscriptionRadioButtons(),
          if (currentKidCount == kidCount)
            AppButton(
              title: "Next",
              onTap: () {
                if (_aliasNameController.text.isNotEmpty ||
                    _parentFirstNameController.text.isNotEmpty ||
                    _parentMiddleNameController.text.isNotEmpty ||
                    _lastNameController.text.isNotEmpty) {
                  Kid kid = Kid(
                      alliasName: _aliasNameController.text,
                      parentName: _parentFirstNameController.text,
                      parentLastName: _lastNameController.text,
                      parentMiddleName: _parentMiddleNameController.text,
                      subscriptionType: "free",
                      gender: _gender.toString(),
                      age: _childAge,
                      DOB: _selectedDate);
                  context.read<ChildrenProvider>().addKid(kid);
                  // AuthService()
                  //     .registerKids(context.read<ChildrenProvider>().kids);
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DisplayKids(),
                      ));
                } else {
                  showSnackBar(context, "Please enter required fields");
                }
              },
            ),
          _buildNavigationButtons(kidCount)
        ],
      ),
    );
  }

  Widget _buildNavigationButtons(int kidCount) {
    return Consumer<ChildrenProvider>(
      builder: (context, value, child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (currentKidCount > 1)
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.navigate_before),
              ),
            Text("$currentKidCount/$kidCount"),
            IconButton(
              onPressed: () {
                if ((kidCount > currentKidCount)) {
                  if (_aliasNameController.text.isNotEmpty &&
                      _parentFirstNameController.text.isNotEmpty &&
                      _parentMiddleNameController.text.isNotEmpty &&
                      _lastNameController.text.isNotEmpty) {
                    Kid kid = Kid(
                        alliasName: _aliasNameController.text,
                        parentName: _parentFirstNameController.text,
                        parentLastName: _lastNameController.text,
                        parentMiddleName: _parentMiddleNameController.text,
                        subscriptionType: "free",
                        gender: _gender.toString(),
                        age: _childAge,
                        DOB: _selectedDate);
                    context.read<ChildrenProvider>().addKid(kid);
                    setState(() {
                      currentKidCount++;
                      _controller.forward();
                    });
                  } else {
                    showSnackBar(context, "Please enter required fields");
                  }
                }
              },
              icon: const Icon(Icons.navigate_next),
            ),
          ],
        );
      },
    );
  }

  Widget _buildParentName() {
    return Table(
      children: [
        TableRow(children: [
          FormFieldWidget(
            hintText: "First Name",
            textEditingController: _parentFirstNameController,
          ),
          FormFieldWidget(
            hintText: "Middle Name",
            textEditingController: _parentMiddleNameController,
          ),
        ]),
        TableRow(children: [
          FormFieldWidget(
            hintText: "Last Name",
            textEditingController: _lastNameController,
          ),
          Container()
        ]),
      ],
    );
  }

  String _calculateAge(DateTime birth) {
    DateTime now = DateTime.now();
    Duration age = now.difference(birth);
    int years = age.inDays ~/ 365;
    int months = (age.inDays % 365) ~/ 30;
    int days = ((age.inDays % 365) % 30);
    setState(() {});
    if (!(years == 0 && months == 0 && days == 0)) {
      _childAge = years;
      return "Age result: $years years, $months months, and $days days";
    }
    return "";
  }

  Widget _buildDateTimeFields() {
    return Table(
      children: [
        const TableRow(children: [
          SectionTitle(title: "DOB:"),
        ]),
        TableRow(children: [
          InkWell(
            onTap: () async {
              _selectedDate = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(1930, 8),
                lastDate: DateTime.now(),
              );
              setState(() {});
            },
            child: Container(
              color: AppColors.textFieldHintBackgroundColor,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  _selectedDate != null
                      ? _selectedDate!.printDate()
                      : DateTime.now().printDate(),
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontSize: 17),
                ),
              ),
            ),
          ),
        ])
      ],
    );
  }

  Widget _buildGenderRadioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildRadioButton<Gender>(Gender.boy, "Boy", _gender,
            (Gender? newValue) {
          setState(() {
            _gender = newValue;
          });
        }),
        const SizedBox(width: 21),
        _buildRadioButton<Gender>(Gender.girl, "Girl", _gender,
            (Gender? newValue) {
          setState(() {
            _gender = newValue;
          });
        }),
      ],
    );
  }

  Widget _buildSubscriptionRadioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildRadioButton<SubscriptionType>(
            SubscriptionType.free, "Free", _subscriptionType,
            (SubscriptionType? newValue) {
          setState(() {
            _subscriptionType = newValue;
          });
        }),
        const SizedBox(width: 21),
        _buildRadioButton<SubscriptionType>(
            SubscriptionType.paid, "Paid", _subscriptionType,
            (SubscriptionType? newValue) {
          setState(() {
            _subscriptionType = newValue;
          });
        }),
      ],
    );
  }

  Widget _buildRadioButton<T>(
      T value, String text, T? groupValue, ValueChanged<T?> onChanged) {
    return Expanded(
      child: Container(
        color: AppColors.textFieldHintBackgroundColor,
        child: ListTile(
          title: Text(text),
          leading: Radio<T>(
            activeColor: Colors.orange,
            value: value,
            groupValue: groupValue,
            onChanged: onChanged,
          ),
        ),
      ),
    );
  }
}

class AliasNote extends StatelessWidget {
  const AliasNote({super.key});

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: const TextSpan(
        style: TextStyle(color: AppColors.textFieldHintTextColor),
        children: <TextSpan>[
          TextSpan(text: '*', style: TextStyle(color: Colors.red)),
          TextSpan(
              text:
                  ' Note do not use the child\'s real name here, this will be their screen name'),
        ],
      ),
    );
  }
}
