import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../themes/colors.dart';
import '../themes/theme.dart';
import '../widgets/button.dart';
import '../widgets/forgot_password.dart';
import '../widgets/form_field.dart';
import '../widgets/snackbar.dart';
import 'kid_count.dart';
import 'register.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool isLoading = false;

  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passwordController.dispose();
  }

  void loginUser() async {
    String res = await AuthService().loginUser(
      email: _emailController.text,
      password: _passwordController.text,
    );
    if (res == "success") {
      setState(() {
        isLoading = true;
      });
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => KidCountScreen()));
    } else {
      setState(() {
        isLoading = false;
      });
      showSnackBar(context, res);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blueCloudBackgroundColor,
      body: Center(
          child: Stack(
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Container(
                alignment: Alignment.center,
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width / 1.5,
                decoration: AppTheme.whiteCloudBackgroundDecoration),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height / 3,
            right: 230,
            child: SizedBox(
              width: 450,
              height: 350,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Welcome Back",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 24),
                    ),
                  ),
                  FormFieldWidget(
                    hintText: "User Name or Email",
                    textEditingController: _emailController,
                  ),
                  FormFieldWidget(
                    hintText: "Password",
                    textEditingController: _passwordController,
                  ),
                  AppButton(
                    title: "Sign In",
                    onTap: () => loginUser(),
                  ),
                  ForgotPassword(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Don't have an account yet?"),
                      TextButton(
                        child: Text("Sign Up",
                            style: AppTheme.signUpTextButtonStyle),
                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RegisterScreen(),
                              ));
                        },
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      )),
    );
  }
}
