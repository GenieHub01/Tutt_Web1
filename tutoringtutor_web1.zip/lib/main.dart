import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/kid_count_provider.dart';
import 'providers/kid_information_provider.dart';
import 'screens/login.dart';
import 'screens/register_kids_form.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'themes/colors.dart';


void main() async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => KidCountProvider()),
        ChangeNotifierProvider(create: (_) => ChildrenProvider()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
              seedColor: AppColors.blueCloudBackgroundColor),
          useMaterial3: true,
        ),
        home: LoginScreen());
  }
}
