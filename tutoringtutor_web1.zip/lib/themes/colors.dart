import 'package:flutter/material.dart';

class AppColors {
  static const Color textFieldHintBackgroundColor =
      Color.fromRGBO(249, 249, 249, 1);
  static const Color textFieldfilledHintBackgroundColor =
      Color.fromRGBO(249, 249, 249, 1);

  static const Color textFieldHintTextColor = Color.fromRGBO(0, 0, 0, 0.5);
  static const Color blueCloudBackgroundColor = Color.fromRGBO(65, 155, 239, 1);
}
