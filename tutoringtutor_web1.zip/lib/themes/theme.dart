import 'package:flutter/material.dart';
import 'colors.dart';

class AppTheme {
  const AppTheme();
  static TextStyle textFieldHintStyle = const TextStyle(
      color: AppColors.textFieldHintTextColor, fontWeight: FontWeight.w400);

  static TextStyle signUpTextButtonStyle = const TextStyle(
      color: Colors.black, fontWeight: FontWeight.w600, fontSize: 16);

  static TextStyle signInButtonTextStyle = const TextStyle(
      color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700);

  static BoxDecoration blueCloudBackgroundDecoration = const BoxDecoration(
      image: DecorationImage(
    image: AssetImage("assets/images/Vector.png"),
    fit: BoxFit.cover,
  ));

  static BoxDecoration whiteCloudBackgroundDecoration = const BoxDecoration(
    image: DecorationImage(
      image: AssetImage("assets/images/white_cloud.png"),
      fit: BoxFit.cover,
    ),
  );
  static BoxDecoration signInButtonDecoration = BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      shape: BoxShape.rectangle,
      gradient: AppTheme.signInButtonGradientStyle);

  static LinearGradient signInButtonGradientStyle = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Color.fromRGBO(255, 180, 92, 1),
        Color.fromRGBO(255, 138, 0, 1),
      ]);

  static ButtonStyle signInButtonStyle = ElevatedButton.styleFrom(
    shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(5)),
    backgroundColor: Colors.transparent,
    shadowColor: Colors.transparent,
  );
}
