import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tutoringtutor_web1/widgets/button.dart';
import 'package:tutoringtutor_web1/widgets/snackbar.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  TextEditingController _emailController = TextEditingController();
  final auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        myDialogBox(context);
      },
      child: Text("Forgot Password",
          style: TextStyle(fontWeight: FontWeight.w600)),
    );
  }

  void myDialogBox(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              width: MediaQuery.of(context).size.width / 3,
              height: MediaQuery.of(context).size.height / 4,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Forgot your password",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: Icon(Icons.close))
                      ],
                    ),
                    TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: "Enter email",
                          hintText: "eg: abc@gmail.com"),
                    ),
                    AppButton(
                      title: "Send",
                      width: 100,
                      onTap: () async {
                        await auth
                            .sendPasswordResetEmail(
                                email: _emailController.text)
                            .then((value) {
                          showSnackBar(context,
                              "A reset password link has been sent to your email");
                        }).onError((error, stackTrace) {
                          showSnackBar(context, error.toString());
                        });
                        // terminating the dialog after link sending
                        Navigator.pop(context);
                        // clear the text field
                        _emailController.clear();
                      },
                    )
                  ]),
            ),
          );
        });
  }
}
