import 'package:flutter/material.dart';

import '../themes/theme.dart';

class AppButton extends StatelessWidget {
  const AppButton(
      {super.key,
      required this.title,
      this.onTap,
      this.width = double.infinity});
  final String title;
  final VoidCallback? onTap;
  final double? width;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: 45,
      child: Container(
        decoration: AppTheme.signInButtonDecoration,
        child: ElevatedButton(
          onPressed: onTap,
          style: AppTheme.signInButtonStyle,
          child: Text(
            title,
            style: AppTheme.signInButtonTextStyle,
          ),
        ),
      ),
    );
  }
}
