import 'package:flutter/material.dart';
import 'package:tutoringtutor_web1/themes/colors.dart';
import 'package:tutoringtutor_web1/themes/theme.dart';

class FormFieldWidget extends StatelessWidget {
  FormFieldWidget(
      {super.key,
      required this.hintText,
      this.hintTextStyle,
      this.textEditingController,
      this.textInputType = TextInputType.number,
      this.isObscure = false});
  final String hintText;
  TextStyle? hintTextStyle = AppTheme.textFieldHintStyle;
  final TextEditingController? textEditingController;
  final bool isObscure;
  final TextInputType? textInputType;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
        obscureText: isObscure,
        controller: textEditingController,
        keyboardType: textInputType,
        decoration: InputDecoration(
            border: InputBorder.none,
            fillColor: AppColors.textFieldfilledHintBackgroundColor,
            hintText: hintText,
            hintStyle: hintTextStyle,
            labelStyle: const TextStyle(color: Colors.white),
            filled: true));
  }
}
