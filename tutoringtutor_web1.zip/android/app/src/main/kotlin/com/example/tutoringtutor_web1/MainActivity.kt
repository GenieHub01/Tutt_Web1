package com.example.tutoringtutor_web1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
